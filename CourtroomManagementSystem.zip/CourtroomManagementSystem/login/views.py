from django.shortcuts import redirect, render
import mysql.connector as sql
un=''
pwd=''

# Create your views here.

def UserChoiceAction(request):
    return render(request,'UserChoice.html')

def LoginClientAction(request):

    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Project2OOPs!",database='courtroom_system')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
                pwd=value

        c="select * from dashboard_client where Email='{}' and Password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'LoginRetryClient.html')
        else:
            return redirect('http://127.0.0.1:8000/ClientDashboard')

    return render(request,'LoginClient.html')

def LoginJudgeAction(request):

    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Project2OOPs!",database='courtroom_system')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
                pwd=value

        c="select * from dashboard_judge where Email='{}' and Password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'LoginRetryJudge.html')
        else:
            return redirect('http://127.0.0.1:8000/JudgeDashboard')

    return render(request,'LoginJudge.html')

def LoginLawyerAction(request):

    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Project2OOPs!",database='courtroom_system')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
                pwd=value

        c="select * from dashboard_lawyer where Email='{}' and Password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'LoginRetryLawyer.html')
        else:
            return redirect('http://127.0.0.1:8000/LawyerDashboard')

    return render(request,'LoginLawyer.html')

def LoginAdminAction(request):

    global un,pwd
    if request.method=="POST":
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
               pwd=value

        if (un=='admin@gmail.com' and pwd=='ADMIN') :
            return redirect('http://127.0.0.1:8000/AdminDashboard')
        else:
            return render(request,'LoginRetryAdmin.html')

    return render(request,'LoginAdmin.html')

