from django.shortcuts import render
import mysql.connector as sql
un=''
pwd=''

# Create your views here.

def UserChoiceAction(request):
    return render(request,'UserChoice.html')

def LoginClientAction(request):

    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Project2OOPs!",database='courtroom_system')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
                pwd=value

        c="select * from dashboard_client where Email='{}' and Password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'LoginRetryClient.html')
        else:
            return render(request,'ClientDashboard.html')

    return render(request,'LoginClient.html')

def LoginJudgeAction(request):

    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Project2OOPs!",database='courtroom_system')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
                pwd=value

        c="select * from dashboard_judge where Email='{}' and Password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'LoginRetryJudge.html')
        else:
            return render(request,'JudgeDashboard.html')

    return render(request,'LoginJudge.html')

def LoginLawyerAction(request):

    global un,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="Project2OOPs!",database='courtroom_system')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
                pwd=value

        c="select * from dashboard_lawyer where Email='{}' and Password='{}'".format(un,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'LoginRetryLawyer.html')
        else:
            return render(request,'LawyerDashboard.html')

    return render(request,'LoginLawyer.html')

def LoginAdminAction(request):

    global un,pwd
    if request.method=="POST":
        d=request.POST
        for key,value in d.items():
            if key=="Username":
               un=value
            if key=="Password":
               pwd=value

        if (un==0 and pwd=="ADMIN") :
            return render(request,'AdminDashboard.html')
        else:
            return render(request,'LoginRetryAdmin.html')

    return render(request,'LoginAdmin.html')

