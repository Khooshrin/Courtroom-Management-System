from asyncio.windows_events import NULL
from django.shortcuts import render
from .models import Case, Judge, Lawyer,Client

# Create your views here.

def AdminDashboardAction(request):
    all_cases=Case.objects.all()
    all_lawyers=Lawyer.objects.all()
    all_judges=Judge.objects.all()
    all_clients=Client.objects.all()
    return render(request,'AdminDashboard.html', {'Cases': all_cases,'Lawyers': all_lawyers,'Judges':all_judges,'Clients':all_clients})

def RemoveJudgesAction(request):
    all_judges=Judge.objects.all()
    return render(request,'RemoveJudges.html',{'Judges':all_judges})

def RemoveLawyersAction(request):
    all_lawyers=Lawyer.objects.all()
    return render(request,'RemoveLawyers.html',{'Lawyers':all_lawyers})

def LawyerDashboardAction(request):

    return render(request,'LawyerDashboard.html')

def JudgeDashboardAction(request):

    return render(request,'JudgeDashboard.html')

def ClientDashboardAction(request):

    return render(request,'ClientDashboard.html')
