from django.shortcuts import render

# Create your views here.

def AdminDashboardAction(request):

    return render(request,'AdminDashboard.html')

def LawyerDashboardAction(request):

    return render(request,'LawyerDashboard.html')

def JudgeDashboardAction(request):

    return render(request,'JudgeDashboard.html')

def ClientDashboardAction(request):

    return render(request,'ClientDashboard.html')
